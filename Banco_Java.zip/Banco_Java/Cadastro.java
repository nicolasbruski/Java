import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
 
public class Cadastro {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
    try {
    Connection connManager = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/teste2023",
        "root",
        ""
    );
    System.out.println("Conexão estabelecida!");
    PreparedStatement ps = connManager.prepareStatement("SELECT * FROM usuario");
    ResultSet rs = ps.executeQuery();
    while (rs.next()) {
        System.out.println(rs.getString("nome"));
    }
    ps.close();
    rs.close();
    int opcao = 0;
    do{
    System.out.println("\t Cadastro");
    System.out.println("0 - Inserir Dados");
    System.out.println("1 - Alterar Dados");
    System.out.println("2 - Excluir Dados");
    System.out.println("3 - Visualizar Dados");
    System.out.println("4 - Logar na Conta");
    System.out.println("5 - Sair");

    opcao = sc.nextInt();
    sc.nextLine();
    switch (opcao) {
            case 0:
                System.out.println("Inserir");
                PreparedStatement inserir = connManager.prepareStatement("INSERT INTO usuario(nome, email, senha) VALUES (?, ?, ?)");
                System.out.println("Digite o nome: ");
                String nome = sc.nextLine();
                System.out.println("Digite o email: ");
                String email = sc.nextLine();
                System.out.println("Digite a senha: ");
                String senha = sc.nextLine();
                Usuario usuario = new Usuario(nome, email, senha);
                inserir.setString(1, usuario.getNome());
                inserir.setString(2, usuario.getEmail());
                inserir.setString(3, usuario.getSenha());
                inserir.execute();
                inserir.close();
                break;
            case 1:
                System.out.println("Alterar");
                PreparedStatement alterar = connManager.prepareStatement("UPDATE usuario SET nome = ?, email = ?, senha = ? WHERE id = ?");
                ps = connManager.prepareStatement("SELECT * FROM usuario");
                rs = ps.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getInt("id") + " - " + rs.getString("nome") + " - " + rs.getString("email") + " - " + rs.getString("senha"));
                }
                ps.close();
                rs.close();
                System.out.println("Digite o id do usuario que deseja alterar: ");
                int id = sc.nextInt();
                System.out.println("Digite o nome do usuario que deseja alterar: ");
                nome = sc.nextLine();
                System.out.println("Digite o email do usuario que deseja alterar: ");
                email = sc.nextLine();
                System.out.println("Digite a senha do usuario que deseja alterar: ");
                senha = sc.nextLine();
                usuario = new Usuario(nome, email, senha);
                alterar.setString(1, usuario.getNome());
                alterar.setString(2, usuario.getEmail());
                alterar.setString(3, usuario.getSenha());
                alterar.setInt(4, usuario.getId());
                alterar.execute();
                alterar.close();
                break;
            case 2:
                System.out.println("Excluir");
                PreparedStatement excluir = connManager.prepareStatement("DELETE FROM usuario WHERE id = ?");
                ps = connManager.prepareStatement("SELECT * FROM usuario");
                rs = ps.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getInt("id") + " - " + rs.getString("nome") + " - " + rs.getString("email") + " - " + rs.getString("senha"));
                }
                ps.close();
                rs.close();
                System.out.println("Digite o id do usuario que deseja excluir: ");
                id = sc.nextInt();
                usuario = new Usuario();
                usuario.setId(id);
                excluir.setInt(1, usuario.getId());
                excluir.execute();
                excluir.close();   
                break;
            case 3:
                System.out.println("Visualizar");
                PreparedStatement visualizar = connManager.prepareStatement("SELECT * FROM usuario");
                rs = visualizar.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getInt("id") + " - " + rs.getString("nome") + " - " + rs.getString("email") + " - " + rs.getString("senha"));
                }
                rs.close();
                visualizar.close();
                break;
            case 4:
                System.out.println("Logar");
                PreparedStatement logar = connManager.prepareStatement("SELECT * FROM usuario WHERE email = ? AND senha = ?");
                System.out.println("Digite o email: ");
                email = sc.nextLine();
                System.out.println("Digite a senha: ");
                senha = sc.nextLine();
                usuario = new Usuario(email, senha);
                logar.setString(1, usuario.getEmail());
                logar.setString(2, usuario.getSenha());
                ResultSet rs3 = logar.executeQuery();
                if (rs3.next()) {
                    System.out.println("Usuário  encontrado");
                } else {
                    System.out.println("O usuário não foi encontrado");
                }
                logar.close();
                break;
            case 5:
                System.out.println("Saindo..."); 
                break;

            default:
                break;
            }
        }while(opcao != 5);
            connManager.close();
        } catch (SQLException exception) {
            System.out.println(exception.getMessage());
        }
    }
}